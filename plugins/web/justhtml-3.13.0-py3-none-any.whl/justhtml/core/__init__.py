"""Shared HTML parsing helpers."""
